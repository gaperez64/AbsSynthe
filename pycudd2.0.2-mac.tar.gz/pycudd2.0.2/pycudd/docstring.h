



#define DOCSTRING "PyCUDD 2.0.1\nPython interface to Colorado University Decision Diagram package\nWith BREL support\nCompiled on Aug 13 2014, 13:11:59\nBugs to:aravind@engr.ucsb.edu"
